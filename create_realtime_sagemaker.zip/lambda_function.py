import boto3
import json

def lambda_handler(event, context):
    """Create and deploy real-time SageMaker endpoint for YOLOv5 inference."""

    # AWS resources
    sagemaker = boto3.client('sagemaker')
    
    # Configuration variables
    model_name = "yolov5-licenses"
    endpoint_config_name = "realtime-sagemaker-endpoint-config"
    endpoint_name = "realtime-sagemaker-endpoint"
    role_arn = "arn:aws:iam::683681996350:role/Sagemaker_execution_role"
    model_artifact_path = "s3://platevisionbeta/best.torchscript.tar.gz"    
    image_uri = "763104351884.dkr.ecr.us-west-1.amazonaws.com/pytorch-inference:2.0.0-gpu-py310"
    
    try:
        # Step 1: Create the model
        sagemaker.create_model(
            ModelName=model_name,
            PrimaryContainer={
                'Image': image_uri,
                'ModelDataUrl': model_artifact_path,
                'Environment': {
                    'SAGEMAKER_PROGRAM': 'inference.py',  # Custom script to be executed.
                    'SAGEMAKER_SUBMIT_DIRECTORY': '/opt/ml/model/code',
                    'SAGEMAKER_CONTAINER_LOG_LEVEL': '20'
                }
            },
            ExecutionRoleArn=role_arn
        )

        # Step 2: Create the endpoint configuration
        sagemaker.create_endpoint_config(
            EndpointConfigName=endpoint_config_name,
            ProductionVariants=[
                {
                    'VariantName': 'AllTraffic',
                    'ModelName': model_name,
                    'InitialInstanceCount': 1,
                    'InstanceType': 'ml.g4dn.xlarge'
                }
            ]
        )

        # Step 3: Create the real-time endpoint
        sagemaker.create_endpoint(
            EndpointName=endpoint_name,
            EndpointConfigName=endpoint_config_name
        )

        return {
            'statusCode': 200,
            'body': json.dumps(f'Successfully initiated endpoint creation: {endpoint_name}')
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error creating endpoint: {str(e)}")
        }
