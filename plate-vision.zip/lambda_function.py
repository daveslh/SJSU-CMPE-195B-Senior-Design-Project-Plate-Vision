import json
import boto3
import base64
import requests
from PIL import Image
from io import BytesIO

# Initialize AWS clients
sagemaker = boto3.client('sagemaker-runtime')
dynamodb = boto3.client('dynamodb')
s3 = boto3.client('s3')

# Constants
SAGEMAKER_ENDPOINT_NAME = 'realtime-sagemaker-endpoint'
GOOGLE_OCR_API_URL = 'https://vision.googleapis.com/v1/images:annotate'
GOOGLE_OCR_API_KEY = 'your-google-api-key'
DYNAMODB_TABLE_NAME = 'Licenses'

def lambda_handler(event, context):
    
    # Extract bucket name and object key from the S3 event
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    object_key = event['Records'][0]['s3']['object']['key']

    # Get the image from S3
    response = s3.get_object(Bucket=bucket_name, Key=object_key)
    image_data = response['Body'].read()

    # Call SageMaker endpoint
    sagemaker_response = sagemaker.invoke_endpoint(
        EndpointName=SAGEMAKER_ENDPOINT_NAME,
        ContentType='application/octet-stream',
        Body=image_data
    )

    # Parse SageMaker response
    result = json.loads(sagemaker_response['Body'].read().decode())
    cropped_image_str = result['cropped_image']
    original_image_str = result['original_image']
    inference_result = result['inference_result']

    # Convert cropped image string to bytes and then to Base64 for Google OCR
    cropped_image_bytes = cropped_image_str.encode('latin1')
    cropped_image_base64 = base64.b64encode(cropped_image_bytes).decode('utf-8')

    # Call Google OCR API
    ocr_payload = {
        "requests": [
            {
                "image": {"content": cropped_image_base64},
                "features": [{"type": "TEXT_DETECTION"}]
            }
        ]
    }
    
    ocr_response = requests.post(
        GOOGLE_OCR_API_URL,
        params={'key': GOOGLE_OCR_API_KEY},
        headers={'Content-Type': 'application/json'},
        json=ocr_payload
    )
    
    ocr_results = ocr_response.json()
    
    # Extract text from OCR results (assuming single block of text)
    detected_text = ocr_results['responses'][0].get('textAnnotations', [{}])[0].get('description', '').strip()

    # Compare OCR results with DynamoDB entries
    dynamodb_response = dynamodb.get_item(
        TableName=DYNAMODB_TABLE_NAME,
        Key={'license_plate': {'S': detected_text}}
    )
    
    match_found = 'Item' in dynamodb_response

    # Prepare data for front-end display
    display_data = {
        "original_image_webp": original_image_str,  # Assuming conversion to WebP happens in front-end or elsewhere
        "inference_result": inference_result,
        "match_found": match_found
    }

    # Return or store/display data as needed (e.g., send to another service or store in S3)
    
    return {
        "statusCode": 200,
        "body": json.dumps(display_data),
        "headers": {
            "Content-Type": "application/json"
        }
    }
