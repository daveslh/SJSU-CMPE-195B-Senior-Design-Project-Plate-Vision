# project > 2024-10-08 6:04am
https://universe.roboflow.com/project-v9wmz/project-oh9wn

Provided by a Roboflow user
License: CC BY 4.0

